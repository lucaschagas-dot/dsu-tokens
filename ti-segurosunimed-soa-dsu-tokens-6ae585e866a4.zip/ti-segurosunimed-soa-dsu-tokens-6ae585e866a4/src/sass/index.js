const mixinsBuild = require("./builds/mixins");

mixinsBuild.buildAllPlatforms();
