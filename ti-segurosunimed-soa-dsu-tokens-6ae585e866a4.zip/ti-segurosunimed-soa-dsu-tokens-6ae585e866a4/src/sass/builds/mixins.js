const register = require("../register");
const {
  createThemeMixinFileObj,
  createIndexFileObj,
} = require("../create-file-obj");

const StyleDictionary = require("style-dictionary").extend({
  source: ["dictionary/mixins/*.json"],
  platforms: {
    global: {
      options: {
        showFileHeader: false,
      },
      buildPath: "dist/sass/",
      transforms: ["parseNameToKebab", "keepCSSValues"],
      files: [
        createThemeMixinFileObj("overlay"),
        createThemeMixinFileObj("focus", "focus"),
        createThemeMixinFileObj("hover", "hover"),
        createThemeMixinFileObj("active"),
        createThemeMixinFileObj("text-styles"),
        createIndexFileObj("mixins", "scss"),
      ],
    },
  },
});

register(StyleDictionary);

module.exports = StyleDictionary;
