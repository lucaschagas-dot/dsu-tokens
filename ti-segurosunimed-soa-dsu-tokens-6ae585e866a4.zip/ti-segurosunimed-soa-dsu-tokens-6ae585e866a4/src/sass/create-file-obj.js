const createThemeMixinFileObj = (fileName, elementState) => ({
  destination: `mixins/${fileName}.scss`,
  format: "createSASSMixins",
  options: {
    outputReferences: true,
    elementState,
  },
  filter: {
    attributes: {
      category: "alias",
      type: `mixin-${fileName}`,
    },
  },
});

const createIndexFileObj = (destination, format) => ({
  destination: `${destination}/index.${format}`,
  format: "createIndex",
  options: {
    destination,
    format,
  },
  filter: {
    attributes: {
      category: "index",
    },
  },
});

module.exports = {
  createThemeMixinFileObj,
  createIndexFileObj,
};
