const createGlobalFileObj = (fileName) => ({
  destination: `global/${fileName}.css`,
  format: "css/variables",
  filter: {
    attributes: {
      category: fileName,
    },
  },
});

const createFontsFileObj = (fileName) => ({
  destination: `global/${fileName}.css`,
  format: "createFontImport",
  filter: {
    attributes: {
      category: fileName,
    },
  },
});

const createThemeFileObj = (fileName, destination, theme) => ({
  destination: `${destination}/${fileName}.css`,
  format: "createCSSThemeAlias",
  options: {
    outputReferences: true,
    selector: `[data-theme="${theme}"]`,
  },
  filter: {
    attributes: {
      category: "alias",
      type: fileName,
    },
  },
});

const createThemeMixinFileObj = (fileName, elementState) => ({
  destination: `mixins/${fileName}.css`,
  format: "createCSSMixins",
  options: {
    outputReferences: true,
    elementState,
  },
  filter: {
    attributes: {
      category: "alias",
      type: `mixin-${fileName}`,
    },
  },
});

const createIndexFileObj = (destination, format) => ({
  destination: `${destination}/index.${format}`,
  format: "createIndex",
  options: {
    destination,
    format,
  },
  filter: {
    attributes: {
      category: "index",
    },
  },
});

module.exports = {
  createGlobalFileObj,
  createFontsFileObj,
  createThemeFileObj,
  createThemeMixinFileObj,
  createIndexFileObj,
};
