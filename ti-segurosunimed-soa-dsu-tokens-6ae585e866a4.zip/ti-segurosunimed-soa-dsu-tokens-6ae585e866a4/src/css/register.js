module.exports = (StyleDictionary) => {
  StyleDictionary.registerTransform({
    type: "name",
    name: "parseNameToKebab",
    matcher: () => true,
    transformer: (token) => token.path.join("-"),
  });

  StyleDictionary.registerTransform({
    type: "value",
    name: "keepCSSValues",
    matcher: () => true,
    transformer: (token) => token.value,
  });

  StyleDictionary.registerFormat({
    name: "createFontImport",
    formatter: (dictionary, file, config) => {
      return dictionary.allTokens
        .map((token) =>
          token.original.value
            .map((font) => `@import url('${font}');`)
            .join("\n")
        )
        .join("");
    },
  });

  const aliasToCSSVar = (token, dictionary) => {
    const { usesReference } = dictionary;
    let value = token;

    if (usesReference(token)) {
      value = value.replace(
        /({[^{]+(?=})})/g,
        (match) =>
          `var(--${match.substring(1, match.length - 1).replace(/\./g, "-")})`
      );
    }

    return value;
  };

  StyleDictionary.registerFormat({
    name: "createCSSThemeAlias",
    formatter: (dictionary, file, config) => {
      const { options } = config;
      const selector = options.selector ? ` ${options.selector}` : "";

      return (
        `:root${selector} {\n` +
        dictionary.allTokens
          .map(
            (token) =>
              `\t--${token.name}: ${aliasToCSSVar(
                token.original.value,
                dictionary
              )};`
          )
          .join("\n") +
        "\n}"
      );
    },
  });

  StyleDictionary.registerFormat({
    name: "createCSSMixins",
    formatter: (dictionary, file, config) => {
      const { options } = config;
      const selector = options.selector ? ` ${options.selector}` : "";

      return dictionary.allTokens
        .map((token) => {
          let header = `:root${selector} *::part(${token.name})`;

          if (options.elementState) {
            header =
              `:root${selector} *::part(${token.name}):${options.elementState},\n` +
              `:root${selector} .${token.name}:${options.elementState}`;
          } else {
            header =
              `:root${selector} *::part(${token.name}),\n` +
              `:root${selector} .${token.name}`;
          }

          const objValue = token.original.value;
          const tokenArgs = token.original.attributes.args;

          const replaceArg = (value) => {
            if (!tokenArgs) {
              return value;
            }

            let newValue = value;

            Object.keys(tokenArgs).forEach((arg) => {
              if (newValue.indexOf(`[:${arg}:]`) !== -1) {
                newValue = newValue.replace(
                  new RegExp(`(\\[:${arg}:\\])`, "g"),
                  tokenArgs[arg].default
                );
              }
            });

            return newValue;
          };

          const stringValue = Object.keys(objValue).map(
            (attr) =>
              `\t${attr}: ${replaceArg(
                aliasToCSSVar(objValue[attr], dictionary)
              )};`
          );

          return header + " {\n" + stringValue.join("\n") + "\n}\n";
        })
        .join("\n");
    },
  });

  StyleDictionary.registerFormat({
    name: "createIndex",
    formatter: (dictionary, file, config) => {
      const { files } = file;
      const { options } = config;

      const filesString = files
        .map((file) => {
          if (file.destination.indexOf("index") !== -1) {
            return undefined;
          }

          const fileDestination = file.destination;
          const optionsDestination = options.destination + "/";
          const optionsFormat = "." + options.format;

          const matchDestination = fileDestination.indexOf(optionsDestination);
          const matchFormat = fileDestination.indexOf(optionsFormat);

          if (matchDestination !== -1 && matchFormat !== -1) {
            const fileToImport = fileDestination.slice(
              matchDestination + optionsDestination.length
            );

            return `@import "${fileToImport}";`;
          }
        })
        .filter((file) => file)
        .join("\n");

      return filesString;
    },
  });
};
