const register = require("../register");
const {
  createFontsFileObj,
  createGlobalFileObj,
  createIndexFileObj,
} = require("../create-file-obj");

const StyleDictionary = require("style-dictionary").extend({
  source: ["dictionary/global/*.json"],
  platforms: {
    global: {
      options: {
        showFileHeader: false,
      },
      buildPath: "dist/css/",
      transforms: ["parseNameToKebab", "keepCSSValues"],
      files: [
        createGlobalFileObj("colors"),
        createGlobalFileObj("colors-rgb"),
        createGlobalFileObj("shape"),
        createGlobalFileObj("type"),
        createGlobalFileObj("motion"),
        createIndexFileObj("global", "css"),
      ],
    },
  },
});

register(StyleDictionary);

module.exports = StyleDictionary;
