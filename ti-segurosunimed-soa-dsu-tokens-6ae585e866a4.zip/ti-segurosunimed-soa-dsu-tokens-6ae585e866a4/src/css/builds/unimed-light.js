const register = require('../register');
const {
  createGlobalFileObj,
  createThemeFileObj,
  createIndexFileObj,
} = require('../create-file-obj');

const theme = 'light-theme';
const destination = 'brands/unimed/themes/light';

const StyleDictionary = require('style-dictionary').extend({
  source: [
    'dictionary/global/*.json',
    `dictionary/${destination}/*.json`,
  ],
  platforms: {
    [`unimed-${theme}`]: {
      options: {
        showFileHeader: false,
      },
      buildPath: 'dist/css/',
      transforms: ['parseNameToKebab', 'keepCSSValues'],
      files: [
        createGlobalFileObj('colors', destination),
        createGlobalFileObj('shape', destination),
        createGlobalFileObj('type', destination),
        createGlobalFileObj('motion', destination),
        createThemeFileObj('text-color', destination, theme),
        createThemeFileObj('elements', destination, theme),
        createThemeFileObj('surface', destination, theme),
        createThemeFileObj('action', destination, theme),
        createThemeFileObj('inverse', destination, theme),
        createThemeFileObj('active', destination, theme),
        createThemeFileObj('unselected', destination, theme),
        createThemeFileObj('selected', destination, theme),
        createThemeFileObj('hover', destination, theme),
        createThemeFileObj('overlay', destination, theme),
        createThemeFileObj('disabled', destination, theme),
        createThemeFileObj('negative', destination, theme),
        createThemeFileObj('positive', destination, theme),
        createThemeFileObj('informative', destination, theme),
        createThemeFileObj('warning', destination, theme),
        createThemeFileObj('promote', destination, theme),
        createThemeFileObj('border', destination, theme),
        createThemeFileObj('focus', destination, theme),
        createThemeFileObj('text-styles', destination, theme),
        createThemeFileObj('pressed', destination, theme),
        createIndexFileObj(destination, 'css'),
      ],
    },
  },
});

register(StyleDictionary);

module.exports = StyleDictionary;
