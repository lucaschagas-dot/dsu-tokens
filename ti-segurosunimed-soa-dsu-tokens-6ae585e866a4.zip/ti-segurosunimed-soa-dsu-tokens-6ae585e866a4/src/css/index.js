const globalBuild = require('./builds/global');
const mixinsBuild = require('./builds/mixins');
const unimedLightTheme = require('./builds/unimed-light');
const unimedDarkTheme = require('./builds/unimed-dark');

globalBuild.buildAllPlatforms();
mixinsBuild.buildAllPlatforms();
unimedLightTheme.buildAllPlatforms();
unimedDarkTheme.buildAllPlatforms();
