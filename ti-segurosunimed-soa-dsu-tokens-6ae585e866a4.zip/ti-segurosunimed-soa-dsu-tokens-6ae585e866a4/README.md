# DSU-Tokens

Biblioteca destinada a gerar os tokens necessários para serem consumidos pelos componentes de um Design System.

Toda a arquitetura é baseada no sistema de criação de tokens [Style Dictionary](https://amzn.github.io/style-dictionary/#/), possibilitando uma única configuração base e a transformação da mesma para diversas estruturas de estilização, seja para Web, Mobile, Desktop, Gadgets, entre outros.

De início pode parecer bem complicado como as coisas funcionam, porém depois de uma breve explicação essa estranheza deverá sumir.

Mas caso você já entenda como o Style Dictionary funciona e procura apenas os comandos necessários para tudo funcionar, as próximas linhas ajudarão melhor:

```
# Instalação

npm install
ou
yarn install

# Build

npm run build
ou
yarn build
```

## Estrutura de arquivos

Vamos começar explicando a disposição dos arquivos dentro das suas pastas e nesse caso estamos subentendendo que você entenda como funciona um projeto baseado em [Node](https://nodejs.org/) e usando o gerenciador de pacotes [NPM](https://www.npmjs.com/).

```
+ dictionary            // JSONs de configuração dos Tokens
  + brands              // Tokens de marcas e temas como dark mode
  + global-tokens       // Tokens globais que serve a todos os outros tokens
  + mixins              // Tokens compostos ou agrupamento de atributos

+ src                   // Configurações e customizações de build
  + css                 // Configurações relativas a exportação em CSS
    + builds            // Configurações de entrada para o Style Dictionary
    create-file-obj.js  // Facilitadores para os arquivos de build
    register.js         // Customizações de formatos e transformadores
    index.js            // Arquivo principal de build

  + ...                 // Configurações de outros formatos de exportação

.gitignore
package.json
README.md
```

## Dictionary

A pasta `dictionary` é responsável por organizar os tokens no seu formato "cru", com base nesses arquivos é que o Style Dictionary faz toda magia e transforma eles em tokens usáveis para um Design System. Abaixo você pode ver um exemplo de uma configuração de tokens de cores globais:

```json
{
  "color": {
    "grey": {
      "0": { "value": "#FFFFFF", "attributes": { "category": "colors" } },
      "50": { "value": "#F5F5F5", "attributes": { "category": "colors" } },
      "100": { "value": "#E0E0E0", "attributes": { "category": "colors" } },
      "200": { "value": "#CCCCCC", "attributes": { "category": "colors" } },
      "300": { "value": "#A3A3A3", "attributes": { "category": "colors" } },
      "400": { "value": "#8F8F8F", "attributes": { "category": "colors" } },
      "500": { "value": "#525252", "attributes": { "category": "colors" } },
      "600": { "value": "#3D3D3D", "attributes": { "category": "colors" } },
      "700": { "value": "#333333", "attributes": { "category": "colors" } },
      "800": { "value": "#232323", "attributes": { "category": "colors" } },
      "900": { "value": "#191919", "attributes": { "category": "colors" } }
    },
    ...
  },
  ...
}
```

Com isso, imaginando que seu projeto seja Web e usará as variáveis globais do CSS, a saída transformada dessa configuração ficaria no seguinte formato:

```css
:root {
  --color-grey-0: #ffffff;
  --color-grey-50: #f5f5f5;
  --color-grey-100: #e0e0e0;
  --color-grey-200: #cccccc;
  --color-grey-300: #a3a3a3;
  --color-grey-400: #8f8f8f;
  --color-grey-500: #525252;
  --color-grey-600: #3d3d3d;
  --color-grey-700: #333333;
  --color-grey-800: #232323;
  --color-grey-900: #191919;
  ...;
}
```

## Source (src)

Aqui é onde fica toda a parte de configuração e customização para que o motor do Style Dictionary faça exatamente o que necessitamos.

A pasta `build` é responsável por organizar quais arquivos e tokens serão necessários serem transformados, assim como qual transformador será usado, qual a pasta que será criado o arquivo final, entre outras configurações.

Os arquivos fora da pasta `build` auxiliam nas configurações e reúnem todas informações para que o processo seja feito da melhor forma possível.

## Criação de novos temas

Caso seja necessário criar mais um tema para os tokens, afim de ser utilizado em novos produtos/empresas que apareçam, o Design System precisa se adequar para atender todos esses projetos novos, isso é o que chamamos de um **`Design System Multibrand`**.

No qual é possível utilizar os mesmos componentes para atender multiplos produtos e empresas, e claro, seguindo rigorosamente todo o visual e identidade deste novo produto, isso sem a necessidade de precisar criar ou alterar componentes. Dada esta introdução vamos ao passos:

Obs: Para fins de demonstração, vamos dar um nome para este produto, ele vai ser chamado de **minha-nova-empresa**;

### Estrutura de Pastas

1. Precisamos criar a estrutra das pastas que irá armazenar todos os novos tokens de seu novo produto/empresa. Para isso basta acessar a pasta `dictionary/brands` e aqui criar uma nova pasta com o nome que você quer que o seu novo tema tenha, por padrão seguimos o nome do produto/empresa, no nosso caso `minha-nova-empresa`. Ficando a arquitetura de pastas da seguinte maneira:

```
+ dictionary
  + brands
    + minha-nova-empresa  // Novo pasta com o novo tema
    + matriz              // Pasta atual contendo o tema atual
```

2. E dentro desta nova pasta iremos criar as pastas padrões do projeto, seguido dos temas `light` e `dark`:

```
+ dictionary
  + brands
    + matriz
    + minha-nova-empresa
      + themes            // Pasta da arquitetura padrão do projeto
        + default_theme   // Pasta da arquitetura padrão do projeto
          + light         // Tema light do novo projeto
          + dark          // Tema dark do novo projeto
```

### Criação dos arquivos JSON

Para cada tipo de token, é necessário criar um arquivo `JSON` contendo o token e seus valores, caso os tokens necessitem de ambos os temas **light** e **dark**, é preciso criar o mesmo arquivo `JSON` com o mesmo nome, em ambas as pastas de temas.

#### Arquivo index de export

Dentro das pastas **dark** e **light** é **obrigatório** criar o arquivo `index.json`, pois este arquivo vai ser responsável em exportar todas as folhas de tokens em um único arquivo.

Vamos criar os arquivos:

- minha-nova-empresa/themes/default_theme/**light**/index.json
- minha-nova-empresa/themes/default_theme/**dark**/index.json

e dentro de cada arquivo vamos criar o seguinte conteúdo:<br/>

**LIGHT THEME:**

```json
{
  "minha-nova-empresa-modo-light-index": {
    "value": "",
    "attributes": { "category": "index" }
  }
}
```

**DARK THEME:**

```json
{
  "minha-nova-empresa-modo-dark-index": {
    "value": "",
    "attributes": { "category": "index" }
  }
}
```

Note que aqui existe um padrão a ser seguido, sendo o **prefixo** o nome do seu tema (minha-nova-empresa), seguido de um **identificador** para o modo (modo-light/dark) e o **sufixo** index.

Este identificador do modo é o mesmo que será usado ao se aplicar a troca dos temas entre light <-> dark, pois é usado como valor da tag `data-theme`.

#### Arquivos de tokens

Vamos criar uma folha de token **Text Colors** para os temas dark e light, dentro das pastas abaixo nomeando o arquivo como **`text-colors.json`**:

- minha-nova-empresa/themes/default_theme/**light**/**text-colors.json**
- minha-nova-empresa/themes/default_theme/**dark**/**text-colors.json**

Nós seguimos a estrutura dos tokens de acordo com **Style Guide** do [Style Dictionary](https://amzn.github.io/style-dictionary/#/tokens?id=category-type-item) para criar os **Design Tokens**, então é necessário ter um conhecimento minimo dessa estrutura.
O jeito que é escrito o JSON é como cada token será nomeado e utilizado posteriormente, por exemplo se quisermos criar um token com o nome de **text-paragraph-color** e outro com o nome de **text-heading-color**, devemos:

1. Dizer que a _categoria_ do token é **text**
2. Dizer que o _tipo_ do token é **paragraph**/**heading**
3. Dizer que o seu _item_ é **color**

Com a estrutura em mente montada, devemos atribuir valores e alguns metadados a cada um deles certo? para atribuir esses dados aos tokens basta criar um objeto chamado **value** e outro chamado **attributes**, onde o **value** será o valor do seu token o **attributes** irá conter os metadados do token, para o correto funcionamento nós precisamos definir dois metadados, sendo eles:

- **category** e **type**
  - para tokens não globais nós colocamos o valor do **category** como **`"alias"`**.
  - o valor do **type** deve ser o nome do **Design Token** criado, no nosso caso **`text-colors`**.

O JSON final deve ficar como abaixo, mudando somente o valor dos tokens entre cada modo, **light** e **dark**.

**LIGHT THEME:**

```json
{
  "text": {
    "paragraph": {
      "color": {
        "value": "#f4A222",
        "attributes": { "category": "alias", "type": "text-colors" }
      }
    },
    "heading": {
      "color": {
        "value": "#F0F0F0F0",
        "attributes": { "category": "alias", "type": "text-colors" }
      }
    }
  }
}
```

**DARK THEME:**

```json
{
  "text": {
    "paragraph": {
      "color": {
        "value": "#D6FFF4",
        "attributes": { "category": "alias", "type": "text-colors" }
      }
    },
    "heading": {
      "color": {
        "value": "#E5EFBD",
        "attributes": { "category": "alias", "type": "text-colors" }
      }
    }
  }
}
```

### Configuração de compilação dos Design Tokens

Hoje a biblioteca de **`Design Tokens`** está configurada para compilar para as tecnologias **CSS**, **SASS**, **JavaScript**, **React Naive** e **Styled Components**. E seus arquivos de compilação e configuração estão dentro da pasta `src` das suas respectivas tecnologias.

Para configurar os tokens que vão ser usados com `css` por exemplo, iremos criar dois arquivos, um para cada modo.

```
+ src
  + css
    + builds
      + minha-nova-empresa-light.js // Arquivo com as configurações de build para o modo light
      + minha-nova-empresa-dark.js  // Arquivo com as configurações de build para o modo dark
```

A configuração dentro dos arquivos é praticamente a mesma, o que será mudado somente é as variáveis `theme`, e `destination`, pois aqui são os caminhos relativos e nome de cada modo.

```javascript
const register = require('../register');
const {
  createThemeFileObj, // <- Método responsável por criar e buildar as folhas de tokens>
  createIndexFileObj, // <- método responsável por criar e configurar o arquivo de export com os tokens gerados
} = require('../create-file-obj');

const theme = 'modo-light'; // <- Aqui é o nome do identificador do seu tema, nos exemplos usamos os valores modo-light e modo-dark
const brand = 'minha-nova-empresa'; // <- Nome do novo produto/empresa, nos exemplos usamos minha-nova-empresa
const destination = `brands/${brand}/themes/default_theme/${theme}`;

const StyleDictionary = require('style-dictionary').extend({
  source: [
    'dictionary/global-tokens/*.json',
    `dictionary/${destination}/*.json`,
  ],
  platforms: {
    [`${brand}-${theme}`]: {
      options: { showFileHeader: false },
      buildPath: 'dist/css/',
      transforms: ['parseNameToKebab', 'keepCSSValues'],
      files: [
        // Dentro deste array de files ficará todas as folhas de tokens que
        // criamos dentro de cada modo, no nosso exemplo criamos somente uma
        // folha chamada text-colors, mas aqui você deve adicionar todas as
        // folhas de tokens seguindo exatamente o nome do arquivo criado e do
        // valor do seu atributo type, por exemplo:
        // createThemeFileObj('border', destination, theme),
        createThemeFileObj('text-colors', destination, theme),
        createIndexFileObj(destination, 'css'),
      ],
    },
  },
});

register(StyleDictionary);

module.exports = StyleDictionary;
```

Criado e configurado os arquivos, agora precisamos chamá-los dentro do arquivo `index.js` dentro da pasta `src/css/index.js` para serem executados no build dos demais tokens **`css`**.

Para isso basta importar os que criamos dentro da pasta `builds` e chamar o método nativo do `Style Dictionary` **buildAllPlatforms()**.

```javascript
...
const minhaNovaEmpresaLight = require('./builds/ minha-nova-empresa-light');
const minhaNovaEmpresaDark = require('./builds/ minha-nova-empresa-dark');

minhaNovaEmpresaLight.buildAllPlatforms();
minhaNovaEmpresaDark.buildAllPlatforms();
...
```

Agora ao rodar o comando `npm run build` será criado a arquitetura das pastas e os arquivos dento da pasta `/dist` do seu novo tema.

```
+ dist
  + brands
    + minha-nova-empresa
      + themes
        + default_theme
          + dark
            + index.css
            + text-color.css
          + light
            + index.css
            + text-color.css
```
